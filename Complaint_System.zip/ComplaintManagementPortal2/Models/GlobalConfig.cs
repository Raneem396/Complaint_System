﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ComplaintManagementPortal2.Models
{
    public class GlobalConfig
    {
        public static readonly int PaginationPageSize = 15;
      
        public static readonly string ComplaintsFolder = "~/uploads/Complaint/";


    }
}